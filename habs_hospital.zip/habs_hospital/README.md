## Hospital Appointment Booking System (HABS)

This flutter application provides a platform for patients to book appointments in Kitale District Hospital.
The application encompasses of two user interfaces, that of the patients and that of the doctor.
